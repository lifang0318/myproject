package com.renlink.push.msg.adapter;

import cn.jpush.api.push.PushResult;
import cn.jpush.api.push.model.PushPayload;

import com.renlink.push.msg.lang.JPushProperty;
import com.renlink.push.msg.scheme.MessageScheme;
import com.renlink.push.msg.scheme.NotificationScheme;
import com.renlink.push.msg.scheme.SynthetizeScheme;
import com.renlink.push.msg.utils.JPushUtils;

public class JPushAdapter implements IPushAdapter {

	private String masterSecret;
	private String appKey;
	private Integer timeToLive;

	public String getMasterSecret() {
		return masterSecret;
	}

	public void setMasterSecret(String masterSecret) {
		this.masterSecret = masterSecret;
	}

	public String getAppKey() {
		return appKey;
	}

	public void setAppKey(String appKey) {
		this.appKey = appKey;
	}

	public Integer getTimeToLive() {
		return timeToLive;
	}

	public void setTimeToLive(Integer timeToLive) {
		this.timeToLive = timeToLive;
	}

	private boolean push(JPushProperty property) throws Exception {

		PushPayload load = PushPayload.newBuilder()
				.setPlatform(property.getPlatform())
				.setAudience(property.getAudience())
				.setNotification(property.getNotification())
				.setMessage(property.getMessage()).build();

		try {
			PushResult result = JPushUtils.push(masterSecret, appKey,load);
			return result.isResultOK();
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public boolean pushNotification(NotificationScheme scheme) throws Exception {

		if (scheme == null) {
			throw new NullPointerException("Notification scheme be nll");
		}

		JPushProperty property = JPushProperty.newBuilder().parseScheme(scheme)
				.build();

		return push(property);
	}

	@Override
	public boolean pushMessage(MessageScheme scheme) throws Exception {
		if (scheme == null) {
			throw new NullPointerException("Message scheme be nll");
		}

		JPushProperty property = JPushProperty.newBuilder().parseScheme(scheme)
				.build();
		return push(property);
	}

	@Override
	public boolean push(SynthetizeScheme scheme) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}

	

}
