package com.renlink.push.msg.scheme;

public class WinPhoneNotificationScheme extends NotificationScheme{

	private static final long serialVersionUID = 1L;
	
	private String openPage;

	public String getOpenPage() {
		return openPage;
	}

	public void setOpenPage(String openPage) {
		this.openPage = openPage;
	}
	
}
