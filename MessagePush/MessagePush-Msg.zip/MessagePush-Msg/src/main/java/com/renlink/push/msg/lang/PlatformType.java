package com.renlink.push.msg.lang;

public enum PlatformType {

	ALL, IOS, ANDROID, WINPHONE, IOS_ANDROID, IOS_WINPHONE, ANDROID_WINPHONE;

}
