package com.renlink.push.msg.scheme;

import java.io.Serializable;

public abstract class BaseScheme implements Serializable {

	private static final long serialVersionUID = 1L;

}
