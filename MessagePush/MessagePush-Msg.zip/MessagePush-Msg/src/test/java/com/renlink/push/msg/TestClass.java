package com.renlink.push.msg;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.renlink.push.msg.lang.JPushProperty;
import com.renlink.push.msg.lang.PlatformType;
import com.renlink.push.msg.scheme.NotificationScheme;

public class TestClass {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void test() {
//		fail("Not yet implemented");
		
		NotificationScheme nScheme= new NotificationScheme();
		nScheme.setPlatform(PlatformType.ANDROID);
		nScheme.setAlert("Hello word");
		nScheme.setTitle("通知");
		nScheme.addAlia("aaaa");
		nScheme.addTag("BBB");
		nScheme.addExtra("from", "ziwooo");
		
		JPushProperty property = JPushProperty.newBuilder().parseScheme(nScheme).build();
		System.out.println(property.getPlatform().toJSON());
		System.out.println(property.getNotification().toJSON());
		System.out.println(property.getAudience().toJSON());
		System.out.println(property.getMessage().toJSON());
		
		
		
		

	}

}
